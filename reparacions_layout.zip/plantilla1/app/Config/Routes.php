<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('/pagina','LayoutController::index');
$routes->get('/pagina/layout', 'LayoutController::vista_layout');
$routes->get('/pagina/(:segment)', 'LayoutController::mostrar_pagina/$1');
