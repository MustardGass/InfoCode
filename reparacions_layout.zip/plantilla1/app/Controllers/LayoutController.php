<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class LayoutController extends BaseController
{
    public function index()
    {
        $data['title'] = "pagina";
        $data['saludo'] = "Hola Bienvenido a la Plantilla 1 de CodeIgniter";
        return view("bienvenida", $data);
    }
    
    public function mostrar_pagina($pagina) {
        $data['title']= "Página " . $pagina;
        return view("paginas/" . $pagina, $data);
    }

    public function vista_layout() {

        $data['titol_reparacions']= "Reparacions Assigandes";
        return view('paginas/body', $data);
    }
}
