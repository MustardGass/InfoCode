<footer class="container-fluid text-center text-light" id="_peu">
    <p class="m-5"> &copy; 2023 Infocode</p>
</footer>