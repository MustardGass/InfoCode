
<nav class="dropdown d-flex justify-content-end">
    <img src="<?= base_url('icons/icon_perfil.png'); ?>" alt="img_perfil" id="img_perfil"/>
    <a href="#" class="text-light dropdown-toggle" id="text_dropdown" data-bs-toggle="dropdown" aria-expanded="false">Usuari d'exemple (professor/alumne)</a>
    <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="#">Veure Perfil</a></li>
        <li><a class="dropdown-item" href="#">Tancar sessió</a></li>
    </ul>
</nav>
