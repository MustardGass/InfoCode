<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>
    <div class="container-fluid" style="background-color: #005189;">
        <img src="<?=base_url('img/logo.png');?>" id="est_logo" >
        <h1 class="text-light"  style="margin-left: 100px; margin-top: -80px; font-size: 50px">SSTT</h1>
        <?php echo view("layouts/navbar"); ?>
    </div>
</body>
</html>