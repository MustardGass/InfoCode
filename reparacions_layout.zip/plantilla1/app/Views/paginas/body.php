
<?= $this->extend('layouts/layout'); ?>

<?= $this->section('cuerpo'); ?>

      <div class="float-start" id="est_div_1">
        <div class="float-start" style="width: 10%">
          <img src="<?= base_url('icons/icon_clau.png'); ?>" alt="img_clau" id="icon_clau">
        </div>
        <div class="float-end" style="width: 80%">
            <h2 class="est_repar2" >Reparacions</h2>
        </div>
      </div>

      <div class="float-end" id="est_div_2" >
        <h2 class="mt-4" id="est_titol"><?= $titol_reparacions ?></h2>
        <form class="d-flex" role="search">
        <input class="form-control me-3 border border-primary" id="est_input" type="search" placeholder="Buscar reparacions" aria-label="Search" style="margin-left: 20px">
        </form>
      </div>


  <!-- <div class="container">
    <form class="d-flex" role="search">
      <input class="form-control me-3 border border-primary" id="est_input" type="search" placeholder="Buscar reparacions" aria-label="Search">
      <button class="btn btn-outline-primary" type="submit">Buscar</button>
    </form>
  </div> -->

<?= $this->endSection(); ?>
