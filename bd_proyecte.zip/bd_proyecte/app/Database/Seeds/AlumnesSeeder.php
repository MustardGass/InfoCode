<?php

namespace App\Database\Seeds;

use App\Models\AlumnesModel;
use CodeIgniter\Database\Seeder;
use Faker\Factory;

class AlumnesSeeder extends Seeder
{
    public function run()
    {
        $fake = Factory::create("es_ES");

        $alumneFile = fopen(WRITEPATH."\dades\dadesAlumnes.csv", "r");

        $firstLine = true;

        $model = new AlumnesModel;

        for($i = 0; $i < 10; $i++){
            
            while(($data = fgetcsv($alumneFile, 2000, ";")) !== false){
                if(!$firstLine) {
                    $correu_alumne = $fake->freeEmail();
                    $model->addAlumnes($correu_alumne, $data[0]);
                }
                $firstLine = false;
            } 
        }
        fclose($alumneFile);
    }
}
