<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DispositiuSeeder extends Seeder
{
    public function run()
    {

        $tipus_dispositiu = ["Portátil", "SobreTaula", "Impressora", "Altres"];

        foreach($tipus_dispositiu as $tipus) {
            $data = [
                'tipus_dispositiu' => $tipus
            ];

            $this->db->table('dispositiu')->insert($data);
        }
    }
}
