<?php

namespace App\Database\Seeds;

use App\Models\ProfessorModel;
use CodeIgniter\Database\Seeder;
use Faker\Factory;

class ProfessorSeeder extends Seeder
{
    public function run()
    {
        $fake = Factory::create("es_ES");

        $profesorFile = fopen(WRITEPATH . "\dades\dadesProfessors.csv", "r");

        $firstLine = true;
        
        $model = new ProfessorModel();
      
        for ($i = 0; $i < 4; $i++) {
            while(($data = fgetcsv($profesorFile, 2000, ";")) !== false){
                if(!$firstLine) {
                    $id_xtec = $fake->companyEmail();
                    $nom = $fake->firstName();
                    $cognoms = $fake->lastName();
                    $correu = $fake->freeEmail();
                    $model->addProfessors($id_xtec, $nom, $cognoms, $correu, $data[0]);
                }
                $firstLine = false;
            }
        }

        fclose($profesorFile);
    }
}
