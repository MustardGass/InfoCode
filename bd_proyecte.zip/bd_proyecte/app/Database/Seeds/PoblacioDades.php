<?php

namespace App\Database\Seeds;

use App\Models\PoblacioModel;
use CodeIgniter\Database\Seeder;

class PoblacioDades extends Seeder
{
    public function run()
    {
        $PoblacioFile = fopen(WRITEPATH."\dades\dadesCentres.csv", "r");

        $firsLine = true;

        while(($data = fgetcsv($PoblacioFile, 20000, ";")) !== false) {
            if(!$firsLine) {
                $model = new PoblacioModel;
                $model->addPoblacio($data[17], $data[18]);
            }
            $firsLine = false;
        }
        fclose($PoblacioFile);
    }
}
