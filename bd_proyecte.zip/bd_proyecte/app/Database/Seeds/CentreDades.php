<?php

namespace App\Database\Seeds;

use App\Models\CentreModel;
use CodeIgniter\Database\Seeder;

class CentreDades extends Seeder
{
    public function run()
    {
        $centreFile = fopen(WRITEPATH."\\dades\\dadesCentres.csv", "r");

        $firstLine = true;

        while(($data = fgetcsv($centreFile, 2000, ";")) !== false) {
            if(!$firstLine) {
               
                $model = new CentreModel;

                // 15/01/2024 - Hem intentat arreglar la següen línia, però segueix sense funcionar
                $model->addCentre($data[0], $data[1], $data[6], $data[8], $data[24], $data[14], $data[12], $data[7]);
            }
            $firstLine = false;
        }
        fclose($centreFile);
    }
}