<!-- FITXER DE LLENGUATGE EN CATALÀ -->

return[
    'sstt_header' => 'Serveis Territorials',
    <!-- En usuari ha d'anar l'usuari actual, no el que posi aqui -->
    'usuari' => 'Usuari d'exemple',
    'opt1' => 'Opció 1',
    'opt2' => 'Opció 2',
    'desconnectar' => 'Desconnectar',
    'reparcions_menu' => 'Reparacions',
    'intentari_menu' => 'Inventari',


]
