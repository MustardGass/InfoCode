<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class TicketAlumnesController extends BaseController
{
    public function index()
    {
        $data['title'] = "pagina";
        $data['saludo'] = "Hola Bienvenido a la Plantilla 1 de CodeIgniter";
        return view("bienvenida", $data);
    }
    
    public function vista_layout() {

        $data['titol_reparacions']= "Reparacions Assigandes";
        return view('pages/TicketAlumnes', $data);
    }
}
