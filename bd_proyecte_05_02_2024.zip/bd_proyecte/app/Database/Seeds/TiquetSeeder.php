<?php

namespace App\Database\Seeds;

use App\Models\TiquetModel;
use CodeIgniter\Database\Seeder;
use Faker\Factory;

class TiquetSeeder extends Seeder
{
    public function run()
    {
        $fake = Factory::create("es_ES");

        $tiquetFile = fopen(WRITEPATH."\dades\dadesTiquet.csv", "r");

        $firstLine = true;

        $model = new TiquetModel;

        for($i = 0; $i < 4; $i++){

            while(($data = fgetcsv($tiquetFile, 2000, ";")) !== false){
                if(!$firstLine){
                    $id_tiquet = $fake->randomNumber(5, true);
                    $codi_equip = $fake->randomNumber(5, true);
                    $descripcio_avaria = $fake->paragraphs(2);
                    $data_alta = $fake->dateTime();
                    $data_ultim_modif = $fake->dateTime();
                    $model->addTiquets($id_tiquet, $codi_equip, $descripcio_avaria, $data_alta, $data_ultim_modif, $data[0], $data[1]);
                }
                $firstLine = false;
            }
        }
        fclose($tiquetFile);
    }
}
