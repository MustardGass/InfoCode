<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DispositiuSeeder extends Seeder
{
    public function run()
    {
        $tipus_dispositiu = ["Portátil", "SobreTaula", "Impressora", "Altres"];
        $num_registros = 20;

        shuffle($tipus_dispositiu); //Mezclar array

        for ($i = 0; $i < $num_registros; $i++) {
            $indice = array_rand($tipus_dispositiu);  // Obtener un índice aleatorio del array

            $data = [
                'tipus' => $tipus_dispositiu[$indice]
            ];

            $this->db->table('tipus_dispositiu')->insert($data);
        }
    }
}
