<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DadesModel;

class LecturaCSVController extends BaseController
{
    public function leerCSV()
    {
        $model = new DadesModel();

        $ruta = "C:\Users\jonel\OneDrive\Escritorio\csv\Comarques.csv";

        if(($open = fopen($ruta, "r")) !== false) {
            while(($data = fgetcsv($open, 1000, ",")) !== false){
                $arr[] = $data;
            }
            fclose($open);
        }
    
        foreach($arr as $fila){
            $data = [
                'nom_comarca' => $fila[0]
            ];
            //Ingressar dades desde la funció en el DadesModel
            $model->ingresarDades($data);
        }
        echo "Dades guardades";
    }
}
