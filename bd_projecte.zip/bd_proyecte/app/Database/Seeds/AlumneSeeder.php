<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use Faker\Factory;

class AlumneSeeder extends Seeder
{
    public function run()
    {
        $fake = Factory::create();

        for($i = 0; $i < 5; $i++){
            $data = [
                'correu_alumne' => $fake->email()
            ];
            $this->db->table('alumne')->insert($data);
        }
    }
}
