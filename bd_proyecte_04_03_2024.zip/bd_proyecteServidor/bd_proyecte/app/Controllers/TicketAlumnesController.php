<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AlumnesModel;

class TicketAlumnesController extends BaseController
{
    public function index()
    {
        $data['title'] = "pagina";
        $data['saludo'] = "Hola Bienvenido a la Plantilla 1 de CodeIgniter";
        return view("bienvenida", $data);
    }
    
    public function vista_layout() {

        $model = new AlumnesModel();

        $data['alumnes'] = $model->getAlumne();

        $data['titol_reparacions']= "Reparacions Assigandes";
        return view('pages/TicketAlumnes', $data);
    }
}
